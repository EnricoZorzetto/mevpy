'''
This is the mev_package
'''

if __name__ == "__main__":
    print("mev package run as main")



#  = ["gev_functions", "mev_functions"]

# from gev_functions import *
# from .myfun import *
from .gev_fun import *
from .mev_fun import *


